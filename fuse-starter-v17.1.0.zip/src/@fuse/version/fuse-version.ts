import { Version } from '@fuse/version/version';

export const FUSE_VERSION = new Version('17.1.0').full;
