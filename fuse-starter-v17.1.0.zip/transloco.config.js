module.exports = {
    rootTranslationsPath: 'src/assets/i18n/'
};
